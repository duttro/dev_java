class Root {
    public static void main(String[] arguments) {
        int number = 225;
        System.out.println("The square root of "
            + number
            + " is "
            + Math.sqrt(number)
        );
    }
}
