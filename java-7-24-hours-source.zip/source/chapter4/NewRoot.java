class NewRoot {
    public static void main(String[] args) {
        int number = 625;
        System.out.println("The square root of "
            + number
            + " is "
            + Math.sqrt(number)
        );
    }
}