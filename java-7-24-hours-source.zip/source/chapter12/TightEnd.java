public class TightEnd extends Blocker {
}

