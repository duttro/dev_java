public class WideReceiver extends BallCarrier {
}

