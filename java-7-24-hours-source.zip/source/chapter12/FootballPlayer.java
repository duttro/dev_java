public class FootballPlayer {
    public int number;    
}

