class Thirteens {
    public static void main(String[] arguments) {
        for (int dex = 1; dex <= 400; dex++) {
            int multiple = 13 * dex;
            System.out.print(multiple + " ");
        }
    }
}