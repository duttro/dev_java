class CiaoMondo {
    public static void main(String[] args) {
        String greeting = "Ciao mondo!";
        System.out.println(greeting);
    }
}