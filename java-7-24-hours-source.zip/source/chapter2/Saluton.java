public class Saluton {
    public static void main(String[] arguments) {
        // My first Java program goes here
    }
}
